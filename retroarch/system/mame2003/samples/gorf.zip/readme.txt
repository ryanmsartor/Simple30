Updated all Gorf samples from a working original PCB 1-21-08.
A few samples were replaced with merged samples to enhance accuracy as close to the original PCB as possible.

Gyrovision